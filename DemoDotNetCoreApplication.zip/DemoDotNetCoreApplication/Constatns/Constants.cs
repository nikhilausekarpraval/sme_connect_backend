﻿namespace DemoDotNetCoreApplication.Constatns
{
    public class Constants
    {
        public class ApiResponseType
        {
            public const string Success = "Success";

            public const string Failure = "Failure";

            public const string NotFound = "NotFound";
        }

    }
}
